import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:my_profile/editProfile.dart';
import 'package:my_profile/loginPage.dart';
import 'package:my_profile/widget.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    FocusManager.instance.primaryFocus?.unfocus();
    getData();
  }


  File? _image;
  String? name, email, experience,skills;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          actions: [
            Padding(
              padding: EdgeInsets.symmetric(
                  horizontal: Get.width * 0.05, vertical: Get.height * 0.0),
              child: IconButton(
                  onPressed: () async {
                    SharedPreferences checkEmailPassword =
                        await SharedPreferences.getInstance();
                    checkEmailPassword.setBool("isLogin", false);
                    Get.offAll(LoginPage());
                  },
                  icon: Icon(Icons.logout_outlined,size: 35,)),
            )
          ],
        ),
        body: name == null
            ? Center(child: CircularProgressIndicator())
            : Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: Get.width * 0.05, vertical: Get.height * 0.0),
                child: SingleChildScrollView(
                  physics: NeverScrollableScrollPhysics(),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Align(
                        alignment: Alignment.center,
                        child: SizedBox(
                          height: Get.height * 0.18,
                          width: Get.width*0.35,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(300),
                            child: _image == null
                                ? Image.asset("assets/menfase.png")
                                : Image.file(File(_image!.path),
                                    fit: BoxFit.fitWidth),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: Get.height*0.03,
                      ),
                      Text(
                        "Name :",
                        style: headingStyle,
                      ),
                      Text(
                        name!,
                        style: ansStyle,
                      ),
                      Text(
                        "Email :",
                        style: headingStyle,
                      ),
                      Text(
                        email!,
                        style: ansStyle,
                      ),
                      Text(
                        "Skills :",
                        style: headingStyle,
                      ),
                      Text(
                       skills==null?"": skills!,
                        style: ansStyle,
                      ),
                      Text(
                        "Work Experience :",
                        style: headingStyle,
                      ),
                      Text(
                        experience==null?"":experience!,
                        style: ansStyle,
                      ),
                      SizedBox(
                        height: Get.height * 0.05,
                      ),
                      button(() {
                        Get.offAll(EditProfile(image: _image==null?null:File(_image!.path),email: email==null?null:email!,experience: experience==null?null:experience,name: name==null?null:name,skills: skills==null?null:skills,));
                      }, "Edit Profile")
                    ],
                  ),
                ),
              ));
  }

  getData() async {
    SharedPreferences checkEmailPassword =
        await SharedPreferences.getInstance();
    if (await checkEmailPassword.containsKey("password")) {
      name = checkEmailPassword.getString("password");
    }
    if (await checkEmailPassword.containsKey("email")) {
      email = checkEmailPassword.getString("email");
    }
    if (await checkEmailPassword.containsKey("experience")) {
      experience = checkEmailPassword.getString("experience");
    }
    if (await checkEmailPassword.containsKey("image")) {
      _image = File(checkEmailPassword.getString("image")!);
      print("image file shared"+_image!.path);
    }
    if (await checkEmailPassword.containsKey("skills")) {
      skills = checkEmailPassword.getString("skills");

    }
    setState(() {});
  }

  Future getImageFromGallery() async {
    final pickimage = ImagePicker();

    final pickedFile = await pickimage.pickImage(
        source: ImageSource.gallery,
        imageQuality: 80,
        maxHeight: double.infinity,
        maxWidth: double.infinity);
    if (pickedFile != null) {
      _image = File(pickedFile.path);
      setState(() {

      });
      setState(() {});
      SharedPreferences checkEmailPassword =
          await SharedPreferences.getInstance();
      print("image path"+_image!.path);
      await checkEmailPassword.setString("image", _image!.path);
    } else {
      print("Image is not Picked");
    }
  }
}
