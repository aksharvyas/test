
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:my_profile/splashSceen.dart';
import 'package:shared_preferences/shared_preferences.dart';



void main()async {
   WidgetsFlutterBinding.ensureInitialized();
   SharedPreferences checkEmailPassword =
   await SharedPreferences.getInstance();

   if (await checkEmailPassword.containsKey("isLogin") &&
       await checkEmailPassword.getBool("isLogin") == true) {
     runApp(const MyApp());
   }
   else{
     runApp(const HomePages());
   }

}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      home: SplashScreen(true),
    );
  }
}

class HomePages extends StatelessWidget {
  const HomePages({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      home: SplashScreen(false),
    );
  }
}


