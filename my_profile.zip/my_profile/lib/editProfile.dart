import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:my_profile/homePage.dart';
import 'package:my_profile/widget.dart';
import 'dart:io';

import 'package:shared_preferences/shared_preferences.dart';
class EditProfile extends StatefulWidget {
  String? name,email,skills, experience;
  File? image;


  EditProfile({required this.name, required this.email, required this.skills, required this.experience, required this.image});

  @override
  State<EditProfile> createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {
  File? _image;
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final skillsController = TextEditingController();
  final workExpController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _image=widget.image==null?null:widget.image;
    nameController.text=widget.name==null?"":widget.name!;
    emailController.text=widget.email==null?"":widget.email!;
    skillsController.text=widget.skills==null?"":widget.skills!;
    workExpController.text=widget.experience==null?"":widget.experience!;

  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       body: WillPopScope(
         onWillPop: () {
           return Get.off(HomePage()) as Future<bool>;
         },
         child: Padding(
           padding: EdgeInsets.symmetric(
               horizontal: Get.width * 0.05, vertical: Get.height * 0.05),
           child: SingleChildScrollView(
             physics: NeverScrollableScrollPhysics(),
             child: Form(
               key: _formKey,
               child: Column(
                 crossAxisAlignment: CrossAxisAlignment.center,
                 // mainAxisAlignment: MainAxisAlignment.center,
                 children: [
                   Align(
                     alignment: Alignment.center,
                     child: InkWell(
                       onTap: (){
                         getImageFromGallery();
                       },
                       child: Container(
                         decoration: BoxDecoration(
                           color: Colors.transparent
                         ),
                         height: Get.height * 0.18,
                         width: Get.width*0.35,
                         child: ClipRRect(
                           borderRadius: BorderRadius.circular(300),
                           child: _image == null
                               ? Image.asset("assets/menfase.png")
                               : Image.file(File(_image!.path),
                               fit: BoxFit.cover),
                         ),
                       ),
                     ),
                   ),
                   SizedBox(
                     height: Get.height*0.05,
                   ),
textField(context, nameController, "Enter Name", null, true, (value) {
  if (value == null || value.isEmpty) {
    return 'Name is Empty';
  } else if (value.length < 3) {
    return 'Name should be minimum 3 character';
  }
}),
                   SizedBox(
                     height: Get.height*0.02,
                   ),
                   textField(context, emailController, "Enter Email", null, true,     (value) {
                     final bool isValid = EmailValidator.validate(value!);
                     if(value.isEmpty|| value==null){
                       return 'Email is Empty';
                     }
                     else if(!isValid){
                       return 'Enter Proper Email';
                     }
                   }),
                   SizedBox(
                     height: Get.height*0.02,
                   ),
                   textField(context, skillsController, "Enter Skiils", null, true, (value) {
                     if (value == null || value.isEmpty) {
                       return 'Skiils is Empty';
                     }
                   }),
                   SizedBox(
                     height: Get.height*0.02,
                   ),
                   textField(context, workExpController, "Enter Work Experience", null, true, (value) {
                     if (value == null || value.isEmpty) {
                       return 'Work Experience is Empty';
                     }
                   }),
                   SizedBox(
                     height: Get.height*0.03,
                   ),
                   button(() {
                     submitData();
                   }, "Submit")
                 ],
               ),
             ),
           ),
         ),
       ),
    );
  }
  submitData()async{
    if(_formKey.currentState!.validate()) {
      SharedPreferences checkEmailPassword =
      await SharedPreferences.getInstance();
      await checkEmailPassword.setString("password", nameController.text);
      await checkEmailPassword.setString("email", emailController.text);
      await checkEmailPassword.setString("skills", skillsController.text);
      await checkEmailPassword.setString("experience", workExpController.text);
      if(_image!=null){
      await checkEmailPassword.setString("image", _image!.path);}
      Get.offAll(HomePage());
    }
  }
  Future getImageFromGallery() async {
    final pickimage = ImagePicker();

    final pickedFile = await pickimage.pickImage(
        source: ImageSource.gallery,
        imageQuality: 80,
        maxHeight: double.infinity,
        maxWidth: double.infinity);
    if (pickedFile != null) {
      _image = File(pickedFile.path);
      setState(() {

      });
      setState(() {});
      SharedPreferences checkEmailPassword =
      await SharedPreferences.getInstance();
      print("image path"+_image!.path);
      await checkEmailPassword.setString("image", _image!.path);
    } else {
      print("Image is not Picked");
    }
  }
}
