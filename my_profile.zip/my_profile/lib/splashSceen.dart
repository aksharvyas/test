import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_profile/homePage.dart';
import 'package:my_profile/loginPage.dart';

class SplashScreen extends StatefulWidget {
  bool? aks;


  SplashScreen(this.aks);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  bool? transfer;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    transfer=widget.aks;
  }

  @override
  Widget build(BuildContext context) {
    Timer(
        Duration(seconds: 5), (){
          transfer!?Get.offAll(HomePage()):Get.offAll(LoginPage());
    });
    return Scaffold(

      body: Container(
        width: double.infinity,
        height: double.infinity,
      decoration: BoxDecoration(
      gradient: LinearGradient(begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors:   [
      Colors.purple,
      Colors.pinkAccent,
      Colors.brown
      //add more colors
      ],
    )),
        child: Center(
          child: Text("MY PROFILE",
          style: TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.bold,
            color: Colors.white
          ),),
        ),
      ),
    );
  }
}
