import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:my_profile/widget.dart';
import 'constant/stringConstant.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'homePage.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  // ignore: must_call_super
  initState() {
    // ignore: avoid_print
    checkSharedPref();
  }

  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  RxBool isSee = false.obs;
  final _formKey = GlobalKey<FormState>();
  RxBool isChecked = false.obs;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        physics: NeverScrollableScrollPhysics(),
        child: SizedBox(
          // height: double.infinity,
          child: Padding(
            padding: EdgeInsets.symmetric(
                horizontal: Get.width * 0.08, vertical: Get.height * 0.25),
            child: Obx(
              () => Form(
                key: _formKey,
                child: Column(
                  // mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      login,
                      style: loginStyle,
                    ),
                    SizedBox(
                      height: Get.height * 0.05,
                    ),
                    textField(
                        context, emailController, "Enter Email", null, true,
                        (value) {
                      final bool isValid = EmailValidator.validate(value!);
                      if (value.isEmpty || value == null) {
                        return 'Email is Empty';
                      } else if (!isValid) {
                        return 'Enter Proper Email';
                      }
                    }),
                    SizedBox(
                      height: Get.height * 0.02,
                    ),
                    textField(
                        context,
                        passwordController,
                        "Enter Password",
                        IconButton(
                          onPressed: () {
                            isSee.value = !isSee.value;
                          },
                          icon: isSee.value == true
                              ? Icon(Icons.visibility)
                              : Icon(Icons.visibility_off),
                        ),
                        isSee.value, (value) {
                      if (value == null || value.isEmpty) {
                        return 'Password is Empty';
                      } else if (value.length < 3) {
                        return 'Password should be minimum 3 character';
                      }
                    }),
                    SizedBox(
                      height: Get.height * 0.015,
                    ),
                    Row(
                      children: [
                        Checkbox(
                          checkColor: Colors.white,
                          activeColor: Colors.blue,
                          value: isChecked.value,
                          onChanged: (bool? value) {
                            isChecked.value = value!;
                          },
                        ),
                        InkWell(
                          splashColor: Colors.transparent,
                          onTap: () {
                            isChecked.value = !isChecked.value;
                          },
                          child: Text(
                            rememberme,
                            style: remembermeStyle,
                          ),
                        )
                      ],
                    ),
                    SizedBox(
                      height: Get.height * 0.02,
                    ),
                    button(() async {
                      await loginButton();
                    }, login)
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  loginButton() async {
    print("called");
    if (_formKey.currentState!.validate()) {
      SharedPreferences checkEmailPassword =
          await SharedPreferences.getInstance();
      if (isChecked.value == true) {
        await checkEmailPassword.setString(
            "email", emailController.text.toString());
        await checkEmailPassword.setString(
            "password", passwordController.text.toString());
        await checkEmailPassword.setBool("isLogin", true);
        await checkEmailPassword.setBool("isChecked", true);
      } else if (isChecked.value == false) {
        await checkEmailPassword.setString(
            "email", emailController.text.toString());
        await checkEmailPassword.setString(
            "password", passwordController.text.toString());
        await checkEmailPassword.setBool("isLogin", true);
        await checkEmailPassword.setBool("isChecked", true);
      }
      Get.offAll(HomePage());
    }
  }

  checkSharedPref() async {
    SharedPreferences checkEmailPassword =
        await SharedPreferences.getInstance();

    if (checkEmailPassword.containsKey("isChecked") &&
        checkEmailPassword.getBool("isChecked") == true) {
      emailController.text = await checkEmailPassword.getString("email")!;
      passwordController.text = await checkEmailPassword.getString("password")!;
      isChecked.value = (await checkEmailPassword.getBool("isChecked"))!;
    }
    setState(() {});
  }
}
