import 'package:flutter/material.dart';
import 'package:get/get.dart';

const TextStyle loginStyle =TextStyle(
  color: Colors.black,
  fontSize: 30,
  fontWeight: FontWeight.bold
);
const TextStyle remembermeStyle= TextStyle(
  fontSize: 14,
  fontWeight: FontWeight.w600
);

 button( Function() onPress, String text){
  return     InkWell(
    onTap: onPress,
    child: SizedBox(
     width: double.infinity,
     child: DecoratedBox(
         decoration: BoxDecoration(
          gradient: LinearGradient(
              colors: [
               Colors.purple,
               Colors.pinkAccent,
               Colors.brown
               //add more colors
              ]),
          borderRadius: BorderRadius.circular(10),

         ),
         child:SizedBox(
          height: Get.height*0.055,
          child: Container(


              // style: ElevatedButton.styleFrom(
              //     primary: Colors.transparent,
              //     onSurface: Colors.transparent,
              //     shadowColor: Colors.transparent,
              //     //make color or elevated button transparent
              //     shape: RoundedRectangleBorder(
              //         borderRadius: BorderRadius.all(Radius.circular(10))
              //     )
              // ),

              // onPressed: (){
              //
              // },
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(text,style: TextStyle(
                   fontSize: 17,
                    fontWeight: FontWeight.w600,
                    color: Colors.white
                  ),),
                ],
              )
          ),
         ))
    ),
  );
}
 const TextStyle headingStyle = TextStyle(
     fontSize: 20,
     height: 2,
     fontWeight: FontWeight.w500,
  color: Colors.pinkAccent
 );
 const TextStyle ansStyle = TextStyle(
     fontSize: 23,
     height: 1,
     fontWeight: FontWeight.w600,
     color: Colors.black87
 );
textField(BuildContext context, TextEditingController emailController, String hintText, IconButton? icon, bool? isSee, String? Function(String? value) validate) {
  return SizedBox(
    // height: MediaQuery.of(context).size.height * 0.06,
    child: TextFormField(

      validator: validate,
      style: TextStyle(fontWeight: FontWeight.w700, fontSize: 17),
      controller: emailController,

      obscureText: isSee==false?true:false,
      decoration: InputDecoration(
        suffixIcon: icon,
        focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(20.0),
            borderSide: BorderSide(color: Colors.red, width: 3))
        ,  errorBorder:OutlineInputBorder(
          borderRadius: BorderRadius.circular(20.0),
          borderSide: BorderSide(color: Colors.red, width: 3)),
        hintText: hintText,
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(20.0),
            borderSide: BorderSide(color: Colors.blue, width: 3)),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(20.0),
            borderSide: BorderSide(color: Colors.black)),
        prefixStyle: loginStyle,
        contentPadding: EdgeInsets.symmetric(
            horizontal: MediaQuery.of(context).size.width * 0.04),
      ),
    ),
  );
}
